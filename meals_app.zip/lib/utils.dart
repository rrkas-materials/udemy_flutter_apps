const String CATEGORY_SCREEN_ROUTE = '/category-meals';
const String MEALS_DETAIL_SCREEN_ROUTE = '/detail-meals';
const String TABS_SCREEN_ROUTE = '/';
const String SETTINGS_SCREEN_ROUTE = '/setings';
