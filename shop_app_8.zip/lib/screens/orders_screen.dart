import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shopapp/providers/orders.dart';
import 'package:shopapp/widgets/app_drawer.dart';
import 'package:shopapp/widgets/order_item_widget.dart';

class OrdersScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final orderProvider = Provider.of<Orders>(context);
    return Scaffold(
      drawer: AppDrawer(),
      appBar: AppBar(title: Text('Your Orders')),
      body: orderProvider.getOrders.length > 1
          ? ListView.builder(
              itemCount: orderProvider.getOrders.length,
              itemBuilder: (ctx, idx) => OrderItemWidget(
                orderItem: orderProvider.getOrders[idx],
              ),
            )
          : Center(child: Text('No Orders Yet'),),
    );
  }
}
