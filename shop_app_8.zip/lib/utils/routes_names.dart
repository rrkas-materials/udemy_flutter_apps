const PRODUCT_DETAIL_SCREEN_ROUTE = '/product-detail';
const CART_SCREEN_ROUTE = '/cart-screen';
const ORDERS_SCREEN_ROUTE = '/orders-screen';
const USER_PRODUCTS_SCREEN_ROUTE = '/user-products-screen';
const EDIT_PRODUCT_SCREEN_ROUTE = '/edit-product-screen';
